load_Annual_F <- function(End)
{
 .Annual_F(End) 
}

load_Annual_F_CI <- function(End)
{
  .Annual_F_CI(End) 
}

load_Annual_F_per_refpoints <- function(End)
{
  .Annual_F_per_refpoints(End) 
}

load_calibration <- function(End)
{
  .calibration(End) 
}

load_catches_by_age <- function(End)
{
  .catches_by_age(End) 
}

load_catches_by_age_CI <- function(End)
{
  .catches_by_age_CI(End) 
}

load_Annual_F_weighted <- function(End)
{
  .Annual_F_weighted(End)
}

load_Annual_F_weighted <- function(End)
{
  .Annual_F_weighted(End)
}

load_Annual_Z <- function(End)
{
  .Annual_Z(End)
}

load_Annual_Z_Sinclair <- function(End)
{
  .Annual_Z_Sinclair(End)
}

load_firstStepF <- function(para_Z_estimated, param1, param2,param3,param4,param5)
{
  .firstStepF(para_Z_estimated, param1, param2,param3,param4,param5)
}


load_firstStepF_entrataF <- function()
{
  .firstStepF_entrataF()
}

load_firstStepM <- function(para_Z_estimated,param1, param2,param3,param4,param5)
{
  .firstStepM(para_Z_estimated,param1, param2,param3,param4,param5)
}

load_firstStepM_entrataF <- function()
{
  .firstStepM_entrataF()
}


load_FORECAST <- function(End)
{                              
  .FORECAST(End)
}

load_FORECAST_entrataF <- function(End)       
{
  .FORECAST_entrataF(End)
}

load_PRELIFE_EXPLOITED <- function(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM)
{
  .PRELIFE_EXPLOITED(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM)
}

load_PRELIFE_EXPLOITED_entrataF <- function(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM)
{
  .PRELIFE_EXPLOITED_entrataF(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM)
}

load_PRELIFE_UNEXPLOITED <- function(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM)
{
  .PRELIFE_UNEXPLOITED(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM)
}

load_SIMULATION_EXPLOITED <- function(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM,Start,End)
{
  .SIMULATION_EXPLOITED(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM,Start,End)
}

load_SIMULATION_EXPLOITED_entrataF <- function(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM,Start,End)
{
  .SIMULATION_EXPLOITED_entrataF(loca_Fertility,loca_min_BAS.MM,loca_min_BAS.FM,Start,End)
}

load_SIMULATION_UNEXPLOITED <- function(loca_Fertility,Start,End)
{
  .SIMULATION_UNEXPLOITED(loca_Fertility,Start,End)
}