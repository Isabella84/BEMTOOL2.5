# BEMTOOL - Bio-Economic Model TOOLs - version 2.0
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2014
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.




.Annual_F_per_refpoints <- function (End) {

loca <-c(1:(End/INP$Time_slice))
SRO$Annual_F_males_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_females_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_by_gear_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=nb_gears))

SRO$Annual_F_males = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_females = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_by_gear = data.frame(matrix(nrow=End/INP$Time_slice,ncol=nb_gears))

for (i in loca) {
  MFPopulation_temp = SRO$MFPopulation[2+(i-1)*12+11,]
   for (month in (1:11)){
       for(loca_ipop in (GLO$MC_number:2)) { 
       MFPopulation_temp[loca_ipop] = MFPopulation_temp[loca_ipop - 1] * exp(-BAS$MM[loca_ipop - 1] * GLO$Delta_t)   
       } 
    }    # proietta a dicembre solo con mortalit? naturale
    
    sommaMls= sum(MFPopulation_temp[(13):ncol(SRO$MFPopulation)])  
    sommaM= sum(MFPopulation_temp[((13)+INP$min_ageM*12):(INP$max_ageM*12+1-INP$tr)])   
    
     FFPopulation_temp = SRO$FFPopulation[2+(i-1)*12+11,]
   for (month in (1:11)){
       for(loca_ipop in (GLO$FC_number:2)) { 
       FFPopulation_temp[loca_ipop] = FFPopulation_temp[loca_ipop - 1] * exp(-BAS$FM[loca_ipop - 1] * GLO$Delta_t)   
       } 
    }    # proietta a dicembre solo con mortalit? naturale
    sommaFls= sum(FFPopulation_temp[(13):ncol(SRO$FFPopulation)])     
    sommaF= sum(FFPopulation_temp[((13)+INP$min_ageF*12):(INP$max_ageF*12+1-INP$tr)])     
                 
SRO$Annual_F_males_ls[i,1] = - log(sum(SRO$MFPopulation[2+(i-1)*12+11,(13):ncol(SRO$MFPopulation)])/sommaMls)/11*12  #SRO$annual_F_calc_M_num_ls[2+(i-1)*12])
SRO$Annual_F_females_ls[i,1] = - log(sum(SRO$FFPopulation[2+(i-1)*12+11,(13):ncol(SRO$FFPopulation)])/sommaFls)/11*12  #SRO$annual_F_calc_F_num_ls[2+(i-1)*12])
SRO$Annual_F_ls[i,1] = - log((sum(SRO$MFPopulation[2+(i-1)*12+11,(13):ncol(SRO$MFPopulation)])+sum(SRO$FFPopulation[2+(i-1)*12+11,(13):ncol(SRO$FFPopulation)]))/(sommaFls+sommaMls))/11*12

SRO$Annual_F_males[i,1] = - log(sum(SRO$MFPopulation[2+(i-1)*12+11,((13)+INP$min_ageM*12):(INP$max_ageM*12+1-INP$tr)])/ sommaM)/11*12 #SRO$annual_F_calc_M_num[2+(i-1)*12])
SRO$Annual_F_females[i,1] = - log(sum(SRO$FFPopulation[2+(i-1)*12+11,((13)+INP$min_ageF*12):(INP$max_ageF*12+1-INP$tr)])/sommaF)/11*12 #SRO$annual_F_calc_F_num[2+(i-1)*12])
SRO$Annual_F[i,1] = - log((sum(SRO$MFPopulation[2+(i-1)*12+11,((13)+INP$min_ageM*12):(INP$max_ageM*12+1-INP$tr)])+sum(SRO$FFPopulation[2+(i-1)*12+11,((13)+INP$min_ageF*12):(INP$max_ageF*12+1-INP$tr)]))/(sommaM+sommaF))/11*12#(SRO$annual_F_calc_M_num[2+(i-1)*12]+SRO$annual_F_calc_F_num[2+(i-1)*12]))

  for (gear in 1:nb_gears)  {
  #SRO$Annual_F_by_gear_ls[i,gear] = SRO$Annual_F_ls[i,1]  * meanWequals(SRO$pj,nrow(SRO$pj), INP$Time_slice) [i]
  #SRO$Annual_F_by_gear[i,gear] = SRO$Annual_F[i,1]  * meanWequals(SRO$pj,nrow(SRO$pj), INP$Time_slice) [i]
  }

}

}
