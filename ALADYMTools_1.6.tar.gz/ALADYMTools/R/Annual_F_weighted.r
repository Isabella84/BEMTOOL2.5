# ALADYM  Age length based dynamic model
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2013
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# ALADYM is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.

.Annual_F_weighted <- function (End){

if (showCompTime)  {
Annual_F_weighted_ptm <- proc.time()  
}

BAS$indices_MAge <-  data.frame(matrix(cbind(BAS$MAge, trunc(BAS$MAge)), ncol=2))
colnames(BAS$indices_MAge) <- c("age", "age_class")
indices_M <- which(BAS$indices_MAge$age_class %in% c(INP$min_ageM:INP$max_ageM))

BAS$indices_FAge <-  data.frame(matrix(cbind(BAS$FAge, trunc(BAS$FAge)), ncol=2))
colnames(BAS$indices_FAge) <- c("age", "age_class")
indices_F <- which(BAS$indices_FAge$age_class %in% c(INP$min_ageF:INP$max_ageF))                                  

loca <-c(1:(End/INP$Time_slice))

SRO$Annual_F_males_ls_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_females_ls_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_ls_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_by_gear_ls_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=nb_gears))

SRO$Annual_F_males_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_females_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_F_by_gear_weighted = data.frame(matrix(nrow=End/INP$Time_slice,ncol=nb_gears))

SRO$Annual_F_males_ls_weighted[,1] = 999 
SRO$Annual_F_females_ls_weighted[,1] = 999
SRO$Annual_F_ls_weighted[,1] = 999

SRO$Annual_F_males_weighted[,1] = 999
SRO$Annual_F_females_weighted[,1] = 999       
SRO$Annual_F_weighted[,1] = 999
SRO$Annual_F_by_gear_ls_weighted[,] = 999
SRO$Annual_F_by_gear_weighted[,] = 999

 if (showCompTime)  {
 proc_ <- proc.time()
print(paste("Annual_F_weighted [time]::::::::::::::::::::::::::::::::", round(as.numeric(proc_[3]-Annual_F_weighted_ptm[3]),2), "sec" ), quote=F )   
rm(Annual_F_weighted_ptm)
}
}
