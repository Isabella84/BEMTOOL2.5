# ALADYM  Age length based dynamic model
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2013
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# ALADYM is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.

.firstStepM_entrataF <- function() {

n_ages_mal <- INP$MGrowth_tend
# first_age_fem <- 0

if (modulo(INP$tr, 12) == 0 & INP$tr!=0) {
     n_ages_mal <- n_ages_mal - trunc(INP$tr/12) + 1
   # first_age_fem <- trunc(Tr/12) - 1
} else if (trunc(INP$tr/12) > 0 & INP$tr!=0) {
     n_ages_mal <- n_ages_mal - trunc(INP$tr/12)
   # first_age_fem <- trunc(Tr/12)
} 



#
# Initialize the vectors
#

loca_Length_groups                   <- vector(mode="numeric", length=GLO$MC_number)
loca_Age                             <- vector(mode="numeric", length=GLO$MC_number)
loca_M                               <- vector(mode="numeric", length=GLO$MC_number)
loca_Delta_t                         <- vector(mode="numeric", length=GLO$MC_number)
loca_Z                               <- vector(mode="numeric", length=GLO$MC_number)
loca_F                               <- vector(mode="numeric", length=GLO$MC_number)
loca_Selection                       <- vector(mode="numeric", length=GLO$MC_number)
loca_Length_Average                  <- vector(mode="numeric", length=GLO$MC_number)
loca_Maturity                        <- vector(mode="numeric", length=GLO$MC_number)
loca_Initial_Population              <- vector(mode="numeric", length=GLO$MC_number)
loca_Initial_Population_Unfished     <- vector(mode="numeric", length=GLO$MC_number)
loca_Bin_Population                  <- vector(mode="numeric", length=GLO$MC_number)
loca_Bin_Population_Unfished         <- vector(mode="numeric", length=GLO$MC_number)
loca_SS_number                       <- vector(mode="numeric", length=GLO$MC_number)

  loca_Delta_t[] <- 1 / INP$Time_slice
  
  Mfinal_mean_Linf <- vector(mode="numeric", length=GLO$Nrun)
Mfinal_mean_k <- vector(mode="numeric", length=GLO$Nrun)
Mfinal_mean_t0 <- vector(mode="numeric", length=GLO$Nrun)

Mfinal_mean_L50 <- vector(mode="numeric", length=GLO$Nrun)
Mfinal_mean_MR <- vector(mode="numeric", length=GLO$Nrun)

 # age vector from tr (recruitment size)
#-----------------------------------------------------
 # loca_Age[1]<- tr/12
 for(loca_i in (1:GLO$MC_number)) {
   loca_Age[loca_i] <- INP$tr*loca_Delta_t[1] +(loca_i-1) * loca_Delta_t[1]
 }
#-----------------------------------------------------
 
  
#loca_Delta_t[] <- 1 / INP$Time_slice
#
#  # creazione del vettore delle et� (in mesi) se voglio partire da tr
#   loca_Age[1]    <-tr  #et� reclutamento IN MESI

#  for(loca_i in (2:GLO$MC_number)) {
#    loca_Age[loca_i] <- loca_Age[1] + (loca_i - 1) * loca_Delta_t[1]
#  }
  
  

  for(loca_i_run in 1:GLO$Nrun) {

    if(GLO$Nrun > 1) {

      # initialize stochastic parameter

      loca_rMR           <- Sample_a_random(RND$R_fun, RND$R_min, RND$R_max, RND$R_a, RND$R_b) * (1 - INP$Sex_ratio[1])  * 1000        # IN INPUT LE RECLUTE SONO IN MIGLIAIA

      loca_rMGrowth_Linf <- Sample_a_random(RND$MGrowth_Linf_fun, RND$MGrowth_Linf_min, RND$MGrowth_Linf_max, RND$MGrowth_Linf_a, RND$MGrowth_Linf_b)
      loca_rMGrowth_K    <- Sample_a_random(RND$MGrowth_K_fun, RND$MGrowth_K_min, RND$MGrowth_K_max, RND$MGrowth_K_a, RND$MGrowth_K_b)
      loca_rMGrowth_t0   <- Sample_a_random(4, INP$MGrowth_t0_min, INP$MGrowth_t0_max, 0, 0)

      loca_rMML50p       <- Sample_a_random(RND$MML50p_fun, RND$MML50p_min, RND$MML50p_max, RND$MML50p_a, RND$MML50p_b)
      loca_rMML75pL25p   <- Sample_a_random(RND$MML75pL25p_fun, RND$MML75pL25p_min, RND$MML75pL25p_max, RND$MML75pL25p_a, RND$MML75pL25p_b)
      
      Mfinal_mean_Linf[loca_i_run] <- loca_rMGrowth_Linf
      Mfinal_mean_k[loca_i_run] <- loca_rMGrowth_K
      Mfinal_mean_t0[loca_i_run] <- loca_rMGrowth_t0
      
      Mfinal_mean_L50[loca_i_run] <- loca_rMML50p
      Mfinal_mean_MR[loca_i_run] <- loca_rMML75pL25p
    }
   
    # adesso ho 6 numeri "casuali"

# Group Length
# costruzione del vettore delle lunghezze (deterministiche con VBF)

    for(loca_i in (1:GLO$MC_number)) {
      loca_Length_groups[loca_i] <- loca_rMGrowth_Linf * (1 - exp(-loca_rMGrowth_K * (loca_Age[loca_i] - loca_rMGrowth_t0)));
    }

# Average Length

    for(loca_i in 1:(GLO$MC_number - 1)) {
      loca_Length_Average[loca_i] <- loca_rMGrowth_Linf + (loca_Length_groups[loca_i] - loca_Length_groups[loca_i + 1]) / (loca_rMGrowth_K * loca_Delta_t[loca_i])      # formula 3a del paper
    }
    loca_Length_Average[GLO$MC_number] <- loca_Length_groups[GLO$MC_number]

# Weight
# creazione pesi con relazione lunghezza-peso
    loca_Weight <- INP$MWLa * (loca_Length_Average ^ INP$MWLb)    #peso calcolato nella classe media di lunghezza

# Natural Mortality

if (INP$MOPT_M_TYPE == 1) {
    loca_M[] <- INP$MM_fixed
	
} else if (INP$MOPT_M_TYPE == 2) {
    loca_tM <- -(log(abs(1 - exp(loca_rMGrowth_K * loca_rMGrowth_t0))) / loca_rMGrowth_K) + loca_rMGrowth_t0;
    loca_A0 <- 1 - exp(-loca_rMGrowth_K * (loca_tM - loca_rMGrowth_t0));
    loca_A1 <- loca_rMGrowth_K * exp(-loca_rMGrowth_K * (loca_tM - loca_rMGrowth_t0));
    loca_A2 <- -loca_rMGrowth_K^2 * exp(-loca_rMGrowth_K * (loca_tM - loca_rMGrowth_t0)) / 2;
    for(loca_i in (1:GLO$MC_number)) {
      if(loca_Age[loca_i] < loca_tM) {
        loca_M[loca_i] <- loca_rMGrowth_K / (1 - exp(-loca_rMGrowth_K * (loca_Age[loca_i] - loca_rMGrowth_t0)));
      } else {
        loca_M[loca_i] <- loca_rMGrowth_K / (loca_A0 + loca_A1 * (loca_Age[loca_i] - loca_tM) + loca_A2 * (loca_Age[loca_i] - loca_tM)^2);
      }
    }
	
} else if (INP$MOPT_M_TYPE == 3) {
  loca_M <- INP$MM_vector
  
} else if (INP$MOPT_M_TYPE  == 4) { #Prodbiom                                       Linf,k,t0,tmax,Mtmax,l50,a,b,ages
	loca_M <- ProdbiomUnSol(loca_rMGrowth_Linf, loca_rMGrowth_K,loca_rMGrowth_t0,(INP$MGrowth_tend - 1),INP$MMtmax, loca_rMML50p, INP$MWLa,INP$MWLb,c(1:GLO$MC_number) ) 

} else if (INP$MOPT_M_TYPE == 5) { #Gislason
	loca_M <- Gislason(loca_rMGrowth_Linf, loca_rMGrowth_K, loca_Length_Average)
}

# Fishing Mortality
#  creazione matrice delle F per attrezzo ed et�
loca_M_by_age = matrix(nrow = GLO$MC_number,ncol = 0)
   for  (g in 1:nb_gears){ 
   loca_M_by_age_temp <-  Fvector(INP$Fmales[1:n_ages_mal,2+g],loca_Length_Average) 
   loca_M_by_age = cbind(loca_M_by_age,loca_M_by_age_temp)
   }
colnames(loca_M_by_age) = FLEETSEGMENTS_names   


    #if(para_Z_estimated < min(loca_M)) {                       #controlla che Z sia > M, altrimenti mi d� errore
    #  print("Fmax < 0", quote=FALSE)
    #}
    #F_maxM = para_Z_estimated - min(loca_M)

    #loca_MF_matrix = matrix (nrow=nrow(loca_MSelection_sim), ncol=ncol(loca_MSelection_sim))
#                    for (i_F in 1: nrow(loca_MF_matrix)) {
#                      for (j_F in 1:ncol(loca_MF_matrix)) {
#                        fact_F = loca_MSelection_sim[i_F,j_F] * INP$Fishing_efforts[1,j_F]*INP$p_Production[1,j_F]
#                        #fact_F = (sum(loca_FSelection_sim[i_F,])/sum(PjF[i_F,]*pj[1,]))*PjF[i_F,j_F]*pj[1,j_F]
#                        loca_MF_matrix[i_F,j_F] = fact_F* F_maxM      # questa � la F per attrezzo (colonne) e per et�-lunghezza( righe)
#                          }
#                    }
#
loca_MF_matrix = matrix (nrow=length(loca_Length_Average), ncol=nb_gears)
    for (i_F in 1: nrow(loca_MF_matrix)) {
         for (j_F in 1:ncol(loca_MF_matrix)) {
          loca_MF_matrix[i_F,j_F]  = loca_M_by_age[i_F,j_F] * INP$Fishing_efforts[1,j_F]       # questa � la F per attrezzo (colonne) e per et�-lunghezza( righe)
          }
    }
    
    loca_F <- rowSums(loca_MF_matrix)               
    
    # loca_F <- loca_Selection * (para_Z_estimated - min(loca_M))  #*****************************************

# Total Mortality

    loca_Z <- loca_F + loca_M

# Population
#con questa Z calcolo la popolazione nelle varie classi di et�
 
    loca_Initial_Population[1] <- loca_rMR
    for(loca_i in (2:GLO$MC_number)) {
      loca_Initial_Population[loca_i] <- loca_Initial_Population[loca_i - 1] * exp(-loca_Z[loca_i - 1] * loca_Delta_t[loca_i - 1])
    }

# Average Population

    for(loca_i in 1:(GLO$MC_number - 1)) {
      loca_Bin_Population[loca_i] <- (loca_Initial_Population[loca_i] - loca_Initial_Population[loca_i + 1]) / loca_Z[loca_i]
    }
    loca_Bin_Population[GLO$MC_number] <- loca_Initial_Population[GLO$MC_number] / loca_Z[GLO$MC_number]

# Unfished Population

    loca_Initial_Population_Unfished[1] <- loca_rMR
    for(loca_i in (2:GLO$MC_number)) {
      loca_Initial_Population_Unfished[loca_i] <- loca_Initial_Population_Unfished[loca_i - 1] * exp(-loca_M[loca_i - 1] * loca_Delta_t[loca_i - 1])
    }

# Unfished Average Population

    for(loca_i in 1:(GLO$MC_number - 1)) {
      loca_Bin_Population_Unfished[loca_i] <- (loca_Initial_Population_Unfished[loca_i] - loca_Initial_Population_Unfished[loca_i + 1]) / loca_M[loca_i]
    }
    loca_Bin_Population_Unfished[GLO$MC_number] <- loca_Initial_Population_Unfished[GLO$MC_number] / loca_M[GLO$MC_number]

# ogiva di maturit�
    loca_Maturity <- 1 / (1 + exp((log(9) / loca_rMML75pL25p) * (loca_rMML50p - loca_Length_Average)))


# If we look at a single instant


# If we look at the period

    BAS$MFPopulation        <- BAS$MFPopulation    + loca_Bin_Population
    BAS$MUPopulation        <- BAS$MUPopulation    + loca_Bin_Population_Unfished
    BAS$MLength             <- BAS$MLength         + loca_Length_Average

    BAS$MWeight             <- BAS$MWeight         + loca_Weight
    BAS$MM                  <- BAS$MM              + loca_M
    BAS$MMaturity           <- BAS$MMaturity       + loca_Maturity

  }

      BAS$M_mean_Linf <-  mean(Mfinal_mean_Linf, na.rm=T)
    BAS$M_mean_k <-  mean(Mfinal_mean_k, na.rm=T)
      BAS$M_mean_t0 <-  mean(Mfinal_mean_t0, na.rm=T)

                BAS$M_mean_L50 <-  mean(Mfinal_mean_L50, na.rm=T)
      BAS$M_mean_MR <-  mean(Mfinal_mean_MR, na.rm=T)

  BAS$MAge                  <- loca_Age

  # Normalize the mean

  BAS$MFPopulation          <- BAS$MFPopulation    / GLO$Nrun
  BAS$MUPopulation          <- BAS$MUPopulation    / GLO$Nrun
  BAS$MLength               <- BAS$MLength         / GLO$Nrun

  BAS$MWeight               <- BAS$MWeight         / GLO$Nrun
  BAS$MM                    <- BAS$MM              / GLO$Nrun
  BAS$MMaturity             <- BAS$MMaturity       / GLO$Nrun

  BAS$MLinf<-loca_rMGrowth_Linf
  BAS$MK<-loca_rMGrowth_K
  BAS$Mt0<-loca_rMGrowth_t0
  BAS$ML50m<-loca_rMML50p
  BAS$MML7525m<-loca_rMML75pL25p

  
  return(0)
}
