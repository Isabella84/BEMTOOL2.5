# ALADYM  Age length based dynamic model
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2013
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# ALADYM is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.

.firstStepF <- function(para_Z_estimated, param1, param2,param3,param4,param5) {




if (FALSE) {

para_Z_estimated = BAS$FZ_estimated[1]
param1 = INP$param1[1,]
param2 = INP$param2[1,]
param3 = INP$param3[1,]
param4 = INP$param4[1,]
param5 = INP$param5[1,]
}

if (showCompTime)  {
firstStepF_ptm <- proc.time()  
}

#
# Initialize the vectors
#

loca_Length_groups                   <- vector(mode="numeric", length=GLO$FC_number)
loca_Age                             <- vector(mode="numeric", length=GLO$FC_number)
loca_M                               <- vector(mode="numeric", length=GLO$FC_number)
loca_Delta_t                         <- vector(mode="numeric", length=GLO$FC_number)
loca_Z                               <- vector(mode="numeric", length=GLO$FC_number)
loca_F                               <- vector(mode="numeric", length=GLO$FC_number)
loca_Selection                       <- vector(mode="numeric", length=GLO$FC_number)
loca_Length_Average                  <- vector(mode="numeric", length=GLO$FC_number)
loca_Maturity                        <- vector(mode="numeric", length=GLO$FC_number)
loca_Initial_Population              <- vector(mode="numeric", length=GLO$FC_number)
loca_Initial_Population_Unfished     <- vector(mode="numeric", length=GLO$FC_number)
loca_Bin_Population                  <- vector(mode="numeric", length=GLO$FC_number)
loca_Bin_Population_Unfished         <- vector(mode="numeric", length=GLO$FC_number)
loca_SS_number                       <- vector(mode="numeric", length=GLO$FC_number)

  loca_Delta_t[] <- 1 / INP$Time_slice
# age vector from tr (recruitment size)
#-----------------------------------------------------
#for(loca_i in (tr:GLO$FC_number)) {
#    loca_Age[loca_i] <-  (loca_i) * loca_Delta_t[1]     # - 1
# }

Ffinal_mean_Linf <- vector(mode="numeric", length=GLO$Nrun)
Ffinal_mean_k <- vector(mode="numeric", length=GLO$Nrun)
Ffinal_mean_t0 <- vector(mode="numeric", length=GLO$Nrun)

Ffinal_mean_L50 <- vector(mode="numeric", length=GLO$Nrun)
Ffinal_mean_MR <- vector(mode="numeric", length=GLO$Nrun)

#loca_Age[1]<- tr/12
  for(loca_i in (1:GLO$FC_number)) {
   loca_Age[loca_i] <- INP$tr*loca_Delta_t[1] +(loca_i-1) * loca_Delta_t[1]
 }
#-----------------------------------------------------

#   selAge_proportions_males <- SGEAR_ext_vec_all("M")

selAge_proportions_females <- SGEAR_ext_vec_age("F", loca_Age)


  for(loca_i_run in 1:GLO$Nrun) {

    if(GLO$Nrun > 1) {

      # initialize stochastic parameter

      loca_rFR           <- Sample_a_random(RND$R_fun, RND$R_min, RND$R_max, RND$R_a, RND$R_b) * INP$Sex_ratio[1]   * 1000        # IN INPUT LE RECLUTE SONO IN MIGLIAIA

      loca_rFGrowth_Linf <- Sample_a_random(RND$FGrowth_Linf_fun, RND$FGrowth_Linf_min, RND$FGrowth_Linf_max, RND$FGrowth_Linf_a, RND$FGrowth_Linf_b)
      loca_rFGrowth_K    <- Sample_a_random(RND$FGrowth_K_fun, RND$FGrowth_K_min, RND$FGrowth_K_max, RND$FGrowth_K_a, RND$FGrowth_K_b)
      loca_rFGrowth_t0   <- Sample_a_random(4, INP$FGrowth_t0_min, INP$FGrowth_t0_max, 0, 0)

      loca_rFML50p       <- Sample_a_random(RND$FML50p_fun, RND$FML50p_min, RND$FML50p_max, RND$FML50p_a, RND$FML50p_b)
      loca_rFML75pL25p   <- Sample_a_random(RND$FML75pL25p_fun, RND$FML75pL25p_min, RND$FML75pL25p_max, RND$FML75pL25p_a, RND$FML75pL25p_b)
      
      Ffinal_mean_Linf[loca_i_run] <- loca_rFGrowth_Linf
      Ffinal_mean_k[loca_i_run] <- loca_rFGrowth_K
      Ffinal_mean_t0[loca_i_run] <- loca_rFGrowth_t0

      Ffinal_mean_L50[loca_i_run] <- loca_rFML50p
      Ffinal_mean_MR[loca_i_run] <- loca_rFML75pL25p

    }

# Group Length

    for(loca_i in (1:GLO$FC_number)) {
      loca_Length_groups[loca_i] <- loca_rFGrowth_Linf * (1 - exp(-loca_rFGrowth_K * (loca_Age[loca_i] - loca_rFGrowth_t0)));
    }

# Average Length

    for(loca_i in 1:(GLO$FC_number - 1)) {
      loca_Length_Average[loca_i] <- loca_rFGrowth_Linf + (loca_Length_groups[loca_i] - loca_Length_groups[loca_i + 1]) / (loca_rFGrowth_K * loca_Delta_t[loca_i])
    }
    loca_Length_Average[GLO$FC_number] <- loca_Length_groups[GLO$FC_number]

# Weight

    loca_Weight <- INP$FWLa * (loca_Length_Average ^ INP$FWLb)

# Natural Mortality

if (INP$FOPT_M_TYPE == 1) {
    loca_M[] <- INP$FM_fixed
	
} else if (INP$FOPT_M_TYPE == 2) {
    loca_tM <- -(log(abs(1 - exp(loca_rFGrowth_K * loca_rFGrowth_t0))) / loca_rFGrowth_K) + loca_rFGrowth_t0;
    loca_A0 <- 1 - exp(-loca_rFGrowth_K * (loca_tM - loca_rFGrowth_t0));
    loca_A1 <- loca_rFGrowth_K * exp(-loca_rFGrowth_K * (loca_tM - loca_rFGrowth_t0));
    loca_A2 <- -loca_rFGrowth_K^2 * exp(-loca_rFGrowth_K * (loca_tM - loca_rFGrowth_t0)) / 2;
    for(loca_i in (1:GLO$FC_number)) {
      if(loca_Age[loca_i] < loca_tM) {
        loca_M[loca_i] <- loca_rFGrowth_K / (1 - exp(-loca_rFGrowth_K * (loca_Age[loca_i] - loca_rFGrowth_t0)));
      } else {
        loca_M[loca_i] <- loca_rFGrowth_K / (loca_A0 + loca_A1 * (loca_Age[loca_i] - loca_tM) + loca_A2 * (loca_Age[loca_i] - loca_tM)^2);
      }
    }
	
} else if (INP$FOPT_M_TYPE == 3) {
  loca_M <- INP$FM_vector
  
} else if (INP$FOPT_M_TYPE  == 4) { #Prodbiom                                       Linf,k,t0,tmax,Mtmax,l50,a,b,ages
	loca_M <- ProdbiomUnSol(loca_rFGrowth_Linf, loca_rFGrowth_K,loca_rFGrowth_t0,(INP$FGrowth_tend - 1),INP$FMtmax, loca_rFML50p, INP$FWLa,INP$FWLb,c(1:GLO$FC_number) ) 

} else if (INP$FOPT_M_TYPE == 5) { #Gislason
	loca_M <- Gislason(loca_rFGrowth_Linf, loca_rFGrowth_K, loca_Length_Average)
}

 loca_FSelection_sim = matrix(nrow = GLO$FC_number,ncol = 0)
 
selLength_proportions_females <- SGEAR_ext_vec_len("F",loca_Length_Average, T) 
 
#
for  (g in 1:nb_gears){	
	 if (as.numeric(as.character(INP$OPT_SG_TYPE[1,g])) !=7){
  # females selectivity
 loca_FSelection_sim_temp <- SGEAR(INP$OPT_SG_TYPE[1,g],INP$param1 [1,g], INP$param2[1,g], INP$param3[1,g],INP$param4[1,g], INP$param5[1,g], BAS$FLength)
 loca_FSelection_sim = cbind(loca_FSelection_sim,loca_FSelection_sim_temp)
 } else if (as.numeric(as.character(INP$OPT_SG_TYPE[1,g])) ==7){ 
		 if (INP$Type[g] =="L"){
		 # females selectivity
		 loca_FSelection_sim_temp <- as.numeric(selLength_proportions_females[[g]][1,]) #SGEAR_ext_vec(BAS$FLength,INP$Sel_vectorF[,c(1,g+1)],INP$Type[g])
		 loca_FSelection_sim = cbind(loca_FSelection_sim,loca_FSelection_sim_temp)
		} else {
		# females selectivity
	                                                # BAS$FAge
		 loca_FSelection_sim_temp <-  as.numeric(selAge_proportions_females[[g]][1,]) #SGEAR_ext_vec(loca_Age,INP$Sel_vectorF[,c(1,g+1)],INP$Type[g])
		 loca_FSelection_sim = cbind(loca_FSelection_sim,loca_FSelection_sim_temp)
		}
 }
}
                    colnames(loca_FSelection_sim) = FLEETSEGMENTS_names   # questa � una matrice contenente le selettivit� per ciascun attrezzo
                    
                   
# Fishing Mortality

    if(para_Z_estimated < min(loca_M)) {
      print("Fmax < 0", quote=FALSE)
    }
    
    F_maxF = para_Z_estimated - min(loca_M)
    
                    loca_FF_matrix = matrix (nrow=nrow(loca_FSelection_sim), ncol=ncol(loca_FSelection_sim))
                    for (i_F in 1: nrow(loca_FF_matrix)) {
                      for (j_F in 1:ncol(loca_FF_matrix)) {
                        fact_F = loca_FSelection_sim[i_F,j_F] * INP$Fishing_efforts[1,j_F]*INP$p_Production[1,j_F]
                        #fact_F = (sum(loca_FSelection_sim[i_F,])/sum(PjF[i_F,]*pj[1,]))*PjF[i_F,j_F]*pj[1,j_F]
                        loca_FF_matrix[i_F,j_F] = fact_F* F_maxF      # questa � la F per attrezzo (colonne) e per et�-lunghezza( righe)
                          }
                    }

    loca_F <- rowSums(loca_FF_matrix)
# Total Mortality

    loca_Z <- loca_F + loca_M

# Population

    loca_Initial_Population[1] <- loca_rFR
    for(loca_i in (2:GLO$FC_number)) {
      loca_Initial_Population[loca_i] <- loca_Initial_Population[loca_i - 1] * exp(-loca_Z[loca_i - 1] * loca_Delta_t[loca_i - 1])
    }

# Average Population

    for(loca_i in 1:(GLO$FC_number - 1)) {
      loca_Bin_Population[loca_i] <- (loca_Initial_Population[loca_i] - loca_Initial_Population[loca_i + 1]) / loca_Z[loca_i]
    }
    loca_Bin_Population[GLO$FC_number] <- loca_Initial_Population[GLO$FC_number] / loca_Z[GLO$FC_number]

# Unfished Population

    loca_Initial_Population_Unfished[1] <- loca_rFR
    for(loca_i in (2:GLO$FC_number)) {
      loca_Initial_Population_Unfished[loca_i] <- loca_Initial_Population_Unfished[loca_i - 1] * exp(-loca_M[loca_i - 1] * loca_Delta_t[loca_i - 1])
    }

# Unfished Average Population

    for(loca_i in 1:(GLO$FC_number - 1)) {
      loca_Bin_Population_Unfished[loca_i] <- (loca_Initial_Population_Unfished[loca_i] - loca_Initial_Population_Unfished[loca_i + 1]) / loca_M[loca_i]
    }
    loca_Bin_Population_Unfished[GLO$FC_number] <- loca_Initial_Population_Unfished[GLO$FC_number] / loca_M[GLO$FC_number]

    loca_Maturity <- 1 / (1 + exp((log(9) / loca_rFML75pL25p) * (loca_rFML50p - loca_Length_Average)))


# If we look at a single instant


# If we look at the period

    BAS$FFPopulation        <- BAS$FFPopulation    + loca_Bin_Population
    BAS$FUPopulation        <- BAS$FUPopulation    + loca_Bin_Population_Unfished
    BAS$FLength             <- BAS$FLength         + loca_Length_Average

    BAS$FWeight             <- BAS$FWeight         + loca_Weight
    BAS$FM                  <- BAS$FM              + loca_M
    BAS$FMaturity           <- BAS$FMaturity       + loca_Maturity

  }
#-------------------------------------------------------------------------------

  BAS$F_mean_Linf <-  mean(Ffinal_mean_Linf, na.rm=T)
    BAS$F_mean_k <-  mean(Ffinal_mean_k, na.rm=T)
      BAS$F_mean_t0 <-  mean(Ffinal_mean_t0, na.rm=T)
      
       BAS$F_mean_L50 <-  mean(Ffinal_mean_L50, na.rm=T)
      BAS$F_mean_MR <-  mean(Ffinal_mean_MR, na.rm=T)

  BAS$FAge                  <- loca_Age

  # Normalize the mean

  BAS$FFPopulation          <- BAS$FFPopulation    / GLO$Nrun
  BAS$FUPopulation          <- BAS$FUPopulation    / GLO$Nrun
  BAS$FLength               <- BAS$FLength         / GLO$Nrun

  BAS$FWeight               <- BAS$FWeight         / GLO$Nrun
  BAS$FM                    <- BAS$FM              / GLO$Nrun
  BAS$FMaturity             <- BAS$FMaturity       / GLO$Nrun

  BAS$FLinf<-loca_rFGrowth_Linf
  BAS$FK<-loca_rFGrowth_K
  BAS$Ft0<-loca_rFGrowth_t0
  BAS$FL50m<-loca_rFML50p
  BAS$FML7525m<-loca_rFML75pL25p
  
  
   if (showCompTime)  {
   proc_ <- proc.time()
# SIMULATION_EXPLOITED_ptm <- proc.time()
print(paste("firstStepF [time]::::::::::::::::::::::::::::::::", round(as.numeric(proc_[3]-firstStepF_ptm[3]),2), "sec" ) , quote=F )   
#print(proc.time() - firstStepF_ptm, quote=F ) 
rm(firstStepF_ptm)
}
  
  return(0)
}
