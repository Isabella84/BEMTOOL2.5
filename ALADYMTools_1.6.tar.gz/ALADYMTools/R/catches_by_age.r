# BEMTOOL - Bio-Economic Model TOOLs - version 2.0
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2014
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# BEMTOOL is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.




.catches_by_age <- function(End){
#---- CATCH IN NUMBERS TABLES

if (FALSE) {
End = forecast -1
}

if (showCompTime)  {
catches_by_age_ptm <- proc.time()  
}


if (IN_BEMTOOL) {
associated_fleetsegment <<- as.vector(cfg[rownames(cfg)==paste("casestudy.S", ALADYM_spe, ".associatedFleetsegment", sep=""), ])   
associated_fleetsegment <<- associated_fleetsegment[!is.na(associated_fleetsegment) & associated_fleetsegment!=""]
associated_fleetsegment_indices <<- which(associated_fleetsegment %in% BMT_FLEETSEGMENTS)
FLEETSEGMENTS_names <<- BMT_FLEETSEGMENTS[associated_fleetsegment_indices]
}

loca <-c(1:(End/INP$Time_slice))

if (exists("num_iter_RPs")) {

    loca_y <- loca
} else {

if (INP$Year_simulation == length(years) ) {
    loca_y <- years
}   else {
loca_y <- c(years, years_forecast)
loca_y <- loca_y[loca]
}

}


#------CREAZIONE ARRAY-------
# MASCHI
# somma i mesi di simulazione per avere gli anni (righe)

NcolM = INP$MGrowth_tend - trunc(INP$tr/12)

catch_gearsM <- vector(mode="list", length = length(FLEETSEGMENTS_names))

#catch_gearsM = array(data=0,dim=c((End/INP$Time_slice),NcolM,length(FLEETSEGMENTS_names)))

for (n in 1:length(FLEETSEGMENTS_names)) {
                                                     
catch2 <- apply(SRO$MFCatch_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (End + 1) , para_pointsMean = INP$Time_slice )
# raggruppamento et? primo anno reclutato
catch1 =  data.frame(matrix(rowSums(catch2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# anni di et? successivi
catch <- t(apply(catch2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(catch2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(catch2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))
catchM = cbind(catch1,catch)

  # list(loca,c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1))),FLEETSEGMENTS_names)
    colnames(catchM) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1)))
  catch_gearsM[[n]] <- catchM
 
  #  # anni di simulazione 
# for (i in 1:nrow(catchM)) {
#      # anni di et? 
#      for (j in 1:ncol(catchM)){
#      catch_gearsM[i,j,n]= catchM[i,j]     
#      }
#  }


}

#dimnames(catch_gearsM) = list(loca,c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1))),FLEETSEGMENTS_names)

# FEMMINE
# raggruppamento mesi

NcolF = INP$FGrowth_tend- trunc(INP$tr/12)

catch_gearsF <- vector(mode="list", length = length(FLEETSEGMENTS_names))
#catch_gearsF = array(data=0,dim=c((End/INP$Time_slice),NcolF,length(FLEETSEGMENTS_names)))

for (n in 1:length(FLEETSEGMENTS_names)) {  

catch2 <- apply(SRO$FFCatch_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (End + 1) , para_pointsMean = INP$Time_slice )  
# raggruppamento et? primo anno reclutato
catch1 =  data.frame(matrix(rowSums(catch2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# anni di et? successivi
catch <- t(apply(catch2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(catch2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(catch2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))

catchF = cbind(catch1,catch)

    colnames(catchF) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1)))
  catch_gearsF[[n]] <- catchF

#for (i in 1:nrow(catchF)){
#      for (j in 1:ncol(catchF)){
#      catch_gearsF[i,j,n]= catchF[i,j]     
#      }
#  }

}

#dimnames(catch_gearsF) =list(loca,c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1))),FLEETSEGMENTS_names)

#----------------------------------------------------------------

#------SALVATAGGIO TABELLE CATCH-------
max_age = max(INP$MGrowth_tend,INP$FGrowth_tend) #max(max_ageM,max_ageF)

catch_fin = data.frame(catch_gearsM[[1]])
if (ncol(catch_fin)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(catch_fin)-trunc(INP$tr/INP$Time_slice))){
  catch_fin =cbind(catch_fin,0)
  }
}

catch_fin$sex= rep("M" ,(End / INP$Time_slice))
catch_fin$gear= rep(FLEETSEGMENTS_names[1] ,(End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  catch_fin2 = data.frame(catch_gearsM[[n]])
  if (ncol(catch_fin2)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(catch_fin2)-trunc(INP$tr/INP$Time_slice))){
    catch_fin2 =cbind(catch_fin2,0)
    }
  }
  catch_fin2$sex= rep("M" ,(End / INP$Time_slice))
  catch_fin2$gear= rep(FLEETSEGMENTS_names[n] ,(End / INP$Time_slice))
  catch_fin=rbind(catch_fin,catch_fin2)
  }

}
# females

catch_finF = data.frame(catch_gearsF[[1]])
if (ncol(catch_finF)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(catch_finF)-trunc(INP$tr/INP$Time_slice))){
  catch_finF =cbind(catch_finF,0)
  }
}

catch_finF$sex= rep("F" ,(End / INP$Time_slice))
catch_finF$gear= rep(FLEETSEGMENTS_names[1] ,(End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  catch_fin2F = data.frame(catch_gearsF[[n]])
  if (ncol(catch_fin2F)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(catch_fin2F)-trunc(INP$tr/INP$Time_slice))){
    catch_fin2F =cbind(catch_fin2F,0)
    }
  }
  catch_fin2F$sex= rep("F" ,(End / INP$Time_slice))
  catch_fin2F$gear= rep(FLEETSEGMENTS_names[n] ,(End / INP$Time_slice))
  catch_finF=rbind(catch_finF,catch_fin2F)
  }

}

#
catch_fin = cbind(loca_y,catch_fin)
catch_finF = cbind(loca_y,catch_finF)

colnames(catch_fin) = c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
colnames(catch_finF)= c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")

#print(paste("M:", ncol(catch_fin) , "F", ncol(catch_finF)))

catch_fin=rbind(catch_finF,catch_fin)

write.table(catch_fin, CATCHBYAGE_table,row.names=FALSE, sep=";")


#----------------------------------------------

##---- LANDINGS IN NUMBERS TABLES
land_gearsM <- vector(mode="list", length = length(FLEETSEGMENTS_names))
#land_gearsM = array(data=0,dim=c((End/INP$Time_slice),NcolM,length(FLEETSEGMENTS_names)))

for (n in 1:length(FLEETSEGMENTS_names)){

land2 <- apply(SRO$MFLanding_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (End + 1) , para_pointsMean = INP$Time_slice )
# raggruppamento et? primo anno reclutato
land1 =  data.frame(matrix(rowSums(land2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# anni di et? successivi
land <- t(apply(land2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(land2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(land2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))
landM = cbind(land1,land)

#land_gearsM[[n]] <- landM
    colnames(landM) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1)))
  land_gearsM[[n]] <- landM

#for (i in 1:nrow(landM)){
#      for (j in 1:ncol(landM)){
#      land_gearsM[i,j,n]= landM[i,j]     
#      }
#  }
     
}

#dimnames(land_gearsM) =list(loca,c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1))),FLEETSEGMENTS_names)

# FEMMINE
# raggruppamento mesi

NcolF = INP$FGrowth_tend- trunc(INP$tr/12)
#land_gearsF = array(data=0,dim=c((End/INP$Time_slice),NcolF,length(FLEETSEGMENTS_names)))
land_gearsF <- vector(mode="list", length = length(FLEETSEGMENTS_names))

for (n in 1:length(FLEETSEGMENTS_names)){
    land2 <- apply(SRO$FFLanding_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (End + 1) , para_pointsMean = INP$Time_slice )   
# raggruppamento et? primo anno reclutato
land1 =  data.frame(matrix(rowSums(land2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# anni di et? successivi
land <- t(apply(land2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(land2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(land2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))
landF = cbind(land1,land)

    colnames(landF) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1)))
  land_gearsF[[n]] <- landF

#for (i in 1:nrow(landF)){
#      for (j in 1:ncol(landF)){
#      land_gearsF[i,j,n]= landF[i,j]     
#      }
#  }
     
}

#dimnames(land_gearsF) =list(loca,c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1))),FLEETSEGMENTS_names)
#----------------------------------------------------------------

#------SALVATAGGIO TABELLE CATCH-------
max_age = max(INP$MGrowth_tend,INP$FGrowth_tend) #max(max_ageM,max_ageF)

land_fin = data.frame(land_gearsM[[1]])
if (ncol(land_fin)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(land_fin)-trunc(INP$tr/INP$Time_slice))){
  land_fin =cbind(land_fin,0)
  }
}

land_fin$sex= rep("M" ,(End / INP$Time_slice))
land_fin$gear= rep(FLEETSEGMENTS_names[1] ,(End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  land_fin2 = data.frame(land_gearsM[[n]])
  if (ncol(land_fin2)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(land_fin2)-trunc(INP$tr/INP$Time_slice))){
    land_fin2 =cbind(land_fin2,0)
    }
  }
  land_fin2$sex= rep("M" ,(End / INP$Time_slice))
  land_fin2$gear= rep(FLEETSEGMENTS_names[n] ,(End / INP$Time_slice))
  land_fin=rbind(land_fin,land_fin2)
  }

}
# females

land_finF = data.frame(land_gearsF[[1]])
if (ncol(land_finF)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(land_finF)-trunc(INP$tr/INP$Time_slice))){
  land_finF =cbind(land_finF,0)
  }
}

land_finF$sex= rep("F" ,(End / INP$Time_slice))
land_finF$gear= rep(FLEETSEGMENTS_names[1] ,(End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  land_fin2F = data.frame(land_gearsF[[n]])
  if (ncol(land_fin2F)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(land_fin2F)-trunc(INP$tr/INP$Time_slice))){
    land_fin2F =cbind(land_fin2F,0)
    }
  }
  land_fin2F$sex= rep("F" ,(End / INP$Time_slice))
  land_fin2F$gear= rep(FLEETSEGMENTS_names[n] ,(End / INP$Time_slice))
  land_finF=rbind(land_finF,land_fin2F)
  }

}

land_fin = cbind(loca_y,land_fin)
land_finF = cbind(loca_y,land_finF)

colnames(land_fin) = c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
colnames(land_finF)= c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")

land_fin=rbind(land_finF,land_fin)

write.table(land_fin, LANDINGBYAGE_table,row.names=FALSE, sep=";")

#DISCARDS AT AGE

#dis_gearsM = array(data=NA,dim=c((End/INP$Time_slice),NcolM,length(FLEETSEGMENTS_names)))
dis_gearsM <- vector(mode="list", length = length(FLEETSEGMENTS_names))

for (n in 1:length(FLEETSEGMENTS_names)){
dis2 <- apply(SRO$MFDiscard_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (End + 1) , para_pointsMean = INP$Time_slice )
# raggruppamento et? primo anno reclutato
dis1 =  data.frame(matrix(rowSums(dis2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# anni di et? successivi
dis <- t(apply(dis2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(dis2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(dis2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))
disM = cbind(dis1,dis)

 colnames(disM) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1)))
  dis_gearsM[[n]] <- disM

#for (i in 1:nrow(disM)){
#      for (j in 1:ncol(disM)){
#      dis_gearsM[i,j,n]= disM[i,j]     
#      }
#  }     
  
}

#dimnames(dis_gearsM) =list(loca,c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$MC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$MC_number+INP$tr)/INP$Time_slice ,1))),FLEETSEGMENTS_names)

# FEMMINE
# raggruppamento mesi

#dis_gearsF = array(data=NA,dim=c((End/INP$Time_slice),NcolF,length(FLEETSEGMENTS_names)))

dis_gearsF <- vector(mode="list", length = length(FLEETSEGMENTS_names))

for (n in 1:length(FLEETSEGMENTS_names)){
   
dis2 <- apply(SRO$FFDiscard_gears[,,n], MARGIN=2, FUN="sumWequals",  para_vectLength = (End + 1) , para_pointsMean = INP$Time_slice )
# raggruppamento et? primo anno reclutato
dis1 =  data.frame(matrix(rowSums(dis2[,1:(INP$Time_slice - modulo(INP$tr,INP$Time_slice))], na.rm=T) , ncol=1) )
# anni di et? successivi
dis <- t(apply(dis2[,(INP$Time_slice - modulo(INP$tr,INP$Time_slice)):ncol(dis2)], MARGIN=1, FUN="sumWequals",  para_vectLength = (ncol(dis2)-(INP$Time_slice - modulo(INP$tr,INP$Time_slice)) + 1 ), para_pointsMean = INP$Time_slice ))
disF = cbind(dis1,dis)

 colnames(disF) <- c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1)))
  dis_gearsF[[n]] <- disF

#for (i in 1:nrow(disF)){
#      for (j in 1:ncol(disF)){
#      dis_gearsF[i,j,n]= disF[i,j]     
#      }
#  }     
}

#dimnames(dis_gearsF) =list(loca,c(paste(seq(trunc(INP$tr/INP$Time_slice),(GLO$FC_number+INP$tr-1)/INP$Time_slice -1 ,1),"-",seq(trunc(INP$tr/12+1,0),(GLO$FC_number+INP$tr)/INP$Time_slice ,1))),FLEETSEGMENTS_names)
#----------------------------------------------------------------

#------SALVATAGGIO TABELLE DISCARD-------
max_age = max(INP$MGrowth_tend,INP$FGrowth_tend) #max(max_ageM,max_ageF)


dis_fin = data.frame(dis_gearsM[[1]])
if (ncol(dis_fin)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(dis_fin)-trunc(INP$tr/INP$Time_slice))){
  dis_fin =cbind(dis_fin,0)
  }
}

dis_fin$sex= rep("M" ,(End / INP$Time_slice))
dis_fin$gear= rep(FLEETSEGMENTS_names[1] ,(End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  dis_fin2 = data.frame(dis_gearsM[[n]])
  if (ncol(dis_fin2)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(dis_fin2)-trunc(INP$tr/INP$Time_slice))){
    dis_fin2 =cbind(dis_fin2,0)
    }
  }
  dis_fin2$sex= rep("M" ,(End / INP$Time_slice))
  dis_fin2$gear= rep(FLEETSEGMENTS_names[n] ,(End / INP$Time_slice))
  dis_fin=rbind(dis_fin,dis_fin2)
  }

}
# females

dis_finF = data.frame(dis_gearsF[[1]])
if (ncol(dis_finF)<(max_age-trunc(INP$tr/INP$Time_slice))){
  for (i in 1:(max_age-ncol(dis_finF)-trunc(INP$tr/INP$Time_slice))){
  dis_finF =cbind(dis_finF,0)
  }
}

dis_finF$sex= rep("F" ,(End / INP$Time_slice))
dis_finF$gear= rep(FLEETSEGMENTS_names[1] ,(End / INP$Time_slice))

if (length(FLEETSEGMENTS_names)!=1) {
  for (n in 2:length(FLEETSEGMENTS_names)){
  dis_fin2F = data.frame(dis_gearsF[[n]])
  if (ncol(dis_fin2F)<(max_age-trunc(INP$tr/INP$Time_slice))){
    for (i in 1:(max_age-ncol(dis_fin2F)-trunc(INP$tr/INP$Time_slice))){
    dis_fin2F =cbind(dis_fin2F,0)
    }
  }
  dis_fin2F$sex= rep("F" ,(End / INP$Time_slice))
  dis_fin2F$gear= rep(FLEETSEGMENTS_names[n] ,(End / INP$Time_slice))
  dis_finF=rbind(dis_finF,dis_fin2F)
  }

}

dis_fin = cbind(loca_y,dis_fin)
dis_finF = cbind(loca_y,dis_finF)

colnames(dis_fin) = c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")
colnames(dis_finF)= c("Year/Age",c(seq(trunc(INP$tr/INP$Time_slice),(max_age-1),1)),"sex","Gear")

dis_fin=rbind(dis_finF,dis_fin)

colnames(dis_fin) = c("Year/Age",c(round(INP$tr/12,0): (max_age-1)),"sex","Gear") 

write.table(dis_fin, DISCARDBYAGE_table, row.names=FALSE, sep=";")


 if (showCompTime)  {
 proc_ <- proc.time()
print(paste("catches_by_age [time]::::::::::::::::::::::::::::::::", round(as.numeric(proc_[3]-catches_by_age_ptm[3]),2), "sec" ), quote=F )   
rm(catches_by_age_ptm)
}


}
