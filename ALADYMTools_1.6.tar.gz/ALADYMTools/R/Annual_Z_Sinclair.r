# ALADYM  Age length based dynamic model
# Authors: G. Lembo, I. Bitetto, M.T. Facchini, M.T. Spedicato 2013
# COISPA Tecnologia & Ricerca, Via dei Trulli 18/20 - (Bari), Italy 
# In case of use of the model, the Authors should be cited.
# If you have any comments or suggestions please contact the following e-mail address: facchini@coispa.it
# ALADYM is believed to be reliable. However, we disclaim any implied warranty or representation about its accuracy, 
# completeness or appropriateness for any particular purpose.

.Annual_Z_Sinclair <- function (End){

if (showCompTime)  {
Annual_Z_Sinclair_ptm <- proc.time()  
}



# End = GLO$L_number
BAS$indices_MAge <-  data.frame(matrix(cbind(BAS$MAge, trunc(BAS$MAge)), ncol=2))
colnames(BAS$indices_MAge) <- c("age", "age_class")
indices_M <- which(BAS$indices_MAge$age_class %in% c(INP$min_ageM:INP$max_ageM))

BAS$indices_FAge <-  data.frame(matrix(cbind(BAS$FAge, trunc(BAS$FAge)), ncol=2))
colnames(BAS$indices_FAge) <- c("age", "age_class")
indices_F <- which(BAS$indices_FAge$age_class %in% c(INP$min_ageF:INP$max_ageF))   


loca <-c(1:(End/INP$Time_slice))
SRO$Annual_Z_males_SINCLAIR = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_Z_females_SINCLAIR = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_Z_SINCLAIR = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))

SRO$Annual_Z_males_SINCLAIR_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_Z_females_SINCLAIR_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))
SRO$Annual_Z_SINCLAIR_ls = data.frame(matrix(nrow=End/INP$Time_slice,ncol=1))


for (i in loca) {
SRO$Annual_Z_males_SINCLAIR_ls[i,1] = - log(sum(SRO$MFPopulation[2+(i-1)*12+11,(13):ncol(SRO$MFPopulation)]) /sum(SRO$MFPopulation[2+(i-1)*11,1:(ncol(SRO$MFPopulation)-12)]))   /11*12
SRO$Annual_Z_females_SINCLAIR_ls[i,1] = - log(sum(SRO$FFPopulation[2+(i-1)*12+11,(13):ncol(SRO$FFPopulation)]) /sum(SRO$FFPopulation[2+(i-1)*11,1:(ncol(SRO$FFPopulation)-12)]))/11*12
SRO$Annual_Z_SINCLAIR_ls[i,1] = - log((sum(SRO$FFPopulation[2+(i-1)*12+11,(13):ncol(SRO$FFPopulation)])+sum(SRO$MFPopulation[2+(i-1)*12+11,(13):ncol(SRO$MFPopulation)])) /(sum(SRO$FFPopulation[2+(i-1)*11,1:(ncol(SRO$FFPopulation)-12)])+sum(SRO$MFPopulation[2+(i-1)*11,1:(ncol(SRO$MFPopulation)-12)]))) /11*12


#SRO$MZa_calculated[loca_i]         <- log(sum(SRO$MFPopulation[loca_i,(loca_min_ageM*12+1):(INP$max_ageM*12+1-INP$tr)]) / (sum(SRO$MFPopulation[loca_i + 12, (loca_min_ageM*12+13):(INP$max_ageM*12+1-INP$tr)])))
if (INP$max_ageM < (INP$MGrowth_tend-1) ) { 
if (INP$tr!=0 & INP$tr <=13) {
SRO$Annual_Z_males_SINCLAIR[i,1] = - log(sum(SRO$MFPopulation[2+(i-1)*12+11,(13+indices_M-INP$tr)]) /sum(SRO$MFPopulation[2+(i-1)*11,(indices_M)]))   /11*12
} else {
SRO$Annual_Z_males_SINCLAIR[i,1] = - log(sum(SRO$MFPopulation[2+(i-1)*12+11,(13+indices_M)]) /sum(SRO$MFPopulation[2+(i-1)*11,(indices_M)]))   /11*12
}
} else {
SRO$Annual_Z_males_SINCLAIR[i,1] = SRO$Annual_Z_males_SINCLAIR_ls[i,1]
}

if (INP$max_ageF < (INP$FGrowth_tend-1) ) {
if (INP$tr!=0 & INP$tr <=13) {
SRO$Annual_Z_females_SINCLAIR[i,1] = - log(sum(SRO$FFPopulation[2+(i-1)*12+11,(13+indices_F-INP$tr)]) /sum(SRO$FFPopulation[2+(i-1)*11,(indices_F)]))  /11*12        # era(13+indices_F-INP$tr+1)
} else {
SRO$Annual_Z_females_SINCLAIR[i,1] = - log(sum(SRO$FFPopulation[2+(i-1)*12+11,(13+indices_F)]) /sum(SRO$FFPopulation[2+(i-1)*11,(indices_F)]))  /11*12
}
} else {
SRO$Annual_Z_females_SINCLAIR[i,1] =  SRO$Annual_Z_females_SINCLAIR_ls[i,1] 
}

SRO$Annual_Z_SINCLAIR[i,1] =   mean(SRO$Annual_Z_females_SINCLAIR[i,1] , SRO$Annual_Z_males_SINCLAIR[i,1] )
#- log((sum(SRO$FFPopulation[2+(i-1)*12+11,(13+indices_F)])+sum(SRO$MFPopulation[2+(i-1)*12+11,(13+indices_M)])) /(sum(SRO$FFPopulation[2+(i-1)*11,indices_F])+sum(SRO$MFPopulation[2+(i-1)*11,indices_M])))   /11*12

}

 if (showCompTime)  {
 proc_ <- proc.time()
print(paste("Annual_Z_Sinclair [time]::::::::::::::::::::::::::::::::", round(as.numeric(proc_[3]-Annual_Z_Sinclair_ptm[3]),2), "sec" ), quote=F )   
rm(Annual_Z_Sinclair_ptm)
}


}
