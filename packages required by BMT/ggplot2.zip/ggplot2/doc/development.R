## ----, echo = FALSE, message = FALSE-------------------------------------
knitr::opts_chunk$set(
  comment = "#>",
  error = FALSE,
  tidy = FALSE
)

## ----, eval = FALSE------------------------------------------------------
#  install.packages(c("devtools", "testthat"))
#  devtools::install_github("klutometis/roxygen")

## ----, eval = FALSE------------------------------------------------------
#  install_deps(dep = T)

