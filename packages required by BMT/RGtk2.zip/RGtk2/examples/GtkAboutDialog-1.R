gtkShowAboutDialog(NULL, "name" = "ExampleCode", "logo" = example_logo,
                   "title" = "About ExampleCode")
