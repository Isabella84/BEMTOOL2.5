matrix$initScale(0.5, 0.5)
pattern$setMatrix(matrix)
